"""
=============================================================================
DISEÑO CON MARGEN DE SHADOWING Y COBERTURA AL 95%
Escenario: Polígono Logístico — Cobertura LTE para terminales de inventario
           y telefonía corporativa en naves y muelles de carga.
=============================================================================

Autor  : Ejercicio de Ingeniería de Telecomunicaciones
Fecha  : Marzo 2026
Librerías: NumPy, SciPy, Matplotlib
=============================================================================
"""

import numpy as np
import scipy.stats as stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib.patches import Circle, FancyArrowPatch
from matplotlib.gridspec import GridSpec
import warnings
warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# Configuración global de estilo
# ---------------------------------------------------------------------------
plt.rcParams.update({
    "font.family":      "DejaVu Sans",
    "font.size":        11,
    "axes.titlesize":   13,
    "axes.labelsize":   12,
    "legend.fontsize":  10,
    "xtick.labelsize":  10,
    "ytick.labelsize":  10,
    "axes.grid":        True,
    "grid.alpha":       0.35,
    "grid.linestyle":   "--",
    "figure.dpi":       150,
    "savefig.dpi":      180,
    "savefig.bbox":     "tight",
})

OUTPUT_DIR = "/home/ubuntu/shadowing_lte/"

# ===========================================================================
# 1. PARÁMETROS DEL SISTEMA
# ===========================================================================
# --- Modelo de propagación (COST-231 Hata / parámetros típicos LTE 900 MHz) ---
FREQ_MHZ        = 900          # Frecuencia portadora [MHz]
HBS_M           = 30           # Altura antena BS [m]
HUE_M           = 1.5          # Altura terminal usuario [m]
EIRP_DBM        = 46           # EIRP de la estación base [dBm]
SENSITIVITY_DBM = -100         # Sensibilidad del receptor LTE [dBm]
NOISE_MARGIN_DB = 3            # Margen de ruido / interferencia [dB]

# Umbral de potencia mínima recibida (sin shadowing)
P_MIN_DBM = SENSITIVITY_DBM + NOISE_MARGIN_DB   # = -97 dBm

# --- Parámetros de shadowing ---
SIGMA_VALUES_DB = [4, 6, 8, 10, 12]   # Desviaciones típicas a estudiar
TARGET_COVERAGE = 0.95                  # Objetivo de cobertura perimetral

# --- Radio de celda preliminar ---
R_PRELIM_M = np.array([500, 700, 900, 1100, 1200])   # [m]

print("=" * 65)
print("  DISEÑO CON MARGEN DE SHADOWING — POLÍGONO LOGÍSTICO LTE")
print("=" * 65)
print(f"  Frecuencia           : {FREQ_MHZ} MHz")
print(f"  EIRP BS              : {EIRP_DBM} dBm")
print(f"  Sensibilidad RX      : {SENSITIVITY_DBM} dBm")
print(f"  Umbral P_min         : {P_MIN_DBM} dBm")
print(f"  Cobertura objetivo   : {TARGET_COVERAGE*100:.0f}%")
print("=" * 65)


# ===========================================================================
# 2. MODELO DE PROPAGACIÓN COST-231 HATA (Suburbano/Rural)
# ===========================================================================
def path_loss_cost231_hata(d_m, f_mhz=FREQ_MHZ, hbs=HBS_M, hue=HUE_M):
    """
    Pérdida de trayecto COST-231 Hata para entorno suburbano/industrial.
    Válido para: 150–2000 MHz, d > 1 km (extrapolamos con precaución a 500 m).

    Retorna PL en dB.
    """
    d_km = d_m / 1000.0
    d_km = np.maximum(d_km, 0.01)   # evitar log(0)

    # Factor de corrección de altura de terminal (área media-urbana)
    a_hue = (1.1 * np.log10(f_mhz) - 0.7) * hue - (1.56 * np.log10(f_mhz) - 0.8)

    # PL media (modelo urbano base)
    PL_urban = (46.3
                + 33.9 * np.log10(f_mhz)
                - 13.82 * np.log10(hbs)
                - a_hue
                + (44.9 - 6.55 * np.log10(hbs)) * np.log10(d_km))

    # Corrección suburbana / industrial (entorno abierto-industrial)
    C_sub = 2 * (np.log10(f_mhz / 28))**2 + 5.4
    PL = PL_urban - C_sub
    return PL


def received_power_dbm(d_m):
    """Potencia media recibida en dBm a distancia d (sin shadowing)."""
    return EIRP_DBM - path_loss_cost231_hata(d_m)


# ===========================================================================
# 3. MARGEN DE SHADOWING (FADE MARGIN)
# ===========================================================================
def fade_margin(sigma_db, coverage_pct=TARGET_COVERAGE):
    """
    Calcula el margen de desvanecimiento por shadowing log-normal.

    Para garantizar que la potencia recibida supere P_min en al menos
    'coverage_pct' de las ubicaciones:

        M_f = sigma * Q^{-1}(1 - coverage_pct)
            = sigma * z_alpha

    donde z_alpha es el percentil (1 - coverage_pct) de N(0,1).
    """
    alpha = 1.0 - coverage_pct
    z_alpha = stats.norm.ppf(1.0 - alpha)   # = Q^{-1}(coverage_pct)
    return sigma_db * z_alpha


# Calcular margen para todos los sigma
print("\n--- Tabla 1: Margen de Shadowing vs Desviación Típica ---")
print(f"{'sigma (dB)':>12} {'z_alpha':>10} {'Margen (dB)':>14}")
print("-" * 40)
margin_table = {}
for sigma in SIGMA_VALUES_DB:
    M = fade_margin(sigma)
    z = stats.norm.ppf(TARGET_COVERAGE)
    margin_table[sigma] = M
    print(f"{sigma:>12.0f} {z:>10.4f} {M:>14.2f}")


# ===========================================================================
# 4. RADIO ÚTIL DE CELDA CON MARGEN
# ===========================================================================
def cell_radius_with_margin(sigma_db, coverage_pct=TARGET_COVERAGE,
                             r_search_max=3000):
    """
    Calcula el radio útil R_util tal que:
        P_rx(R_util) - M_f >= P_min

    Es decir, el radio máximo donde la potencia media menos el margen
    de shadowing sigue superando el umbral mínimo.
    """
    M = fade_margin(sigma_db, coverage_pct)
    P_required = P_MIN_DBM + M   # potencia media necesaria en el borde

    # Búsqueda numérica del radio donde P_rx(R) = P_required
    r_arr = np.linspace(10, r_search_max, 50000)
    p_arr = received_power_dbm(r_arr)
    # Encontrar el último punto donde P_rx >= P_required
    idx = np.where(p_arr >= P_required)[0]
    if len(idx) == 0:
        return 0.0
    return r_arr[idx[-1]]


print("\n--- Tabla 2: Radio Útil de Celda vs sigma ---")
print(f"{'sigma (dB)':>12} {'Margen (dB)':>14} {'R_util (m)':>12} {'Area (km²)':>12}")
print("-" * 54)
radius_table = {}
area_table   = {}
for sigma in SIGMA_VALUES_DB:
    M = margin_table[sigma]
    R = cell_radius_with_margin(sigma)
    A = np.pi * R**2 / 1e6   # km²
    radius_table[sigma] = R
    area_table[sigma]   = A
    print(f"{sigma:>12.0f} {M:>14.2f} {R:>12.1f} {A:>12.4f}")


# ===========================================================================
# 5. ESTIMACIÓN DE COBERTURA DE ÁREA (Modelo de Jakes / Integral)
# ===========================================================================
def area_coverage_probability(sigma_db, R_cell, n_points=200):
    """
    Estima la probabilidad de cobertura de área integrando sobre el disco
    de radio R_cell.

    P_area = (1/pi*R²) * integral_0^R  P_cov(r) * 2*pi*r dr

    donde P_cov(r) = P(P_rx(r) + X_sigma >= P_min)
                   = Q( (P_min - P_rx(r)) / sigma )
                   = 1 - Phi( (P_min - P_rx(r)) / sigma )
    """
    r_arr = np.linspace(1, R_cell, n_points)
    p_rx  = received_power_dbm(r_arr)
    # Probabilidad puntual de cobertura en cada anillo
    z_arr = (P_MIN_DBM - p_rx) / sigma_db
    p_cov = 1.0 - stats.norm.cdf(z_arr)
    # Integración trapezoidal ponderada por área del anillo
    integrand = p_cov * 2 * np.pi * r_arr
    area_total = np.pi * R_cell**2
    P_area = np.trapz(integrand, r_arr) / area_total
    return P_area


print("\n--- Tabla 3: Cobertura de Área vs sigma (R = R_util) ---")
print(f"{'sigma (dB)':>12} {'R_util (m)':>12} {'P_area (%)':>12}")
print("-" * 40)
area_cov_table = {}
for sigma in SIGMA_VALUES_DB:
    R = radius_table[sigma]
    if R > 0:
        Pa = area_coverage_probability(sigma, R) * 100
    else:
        Pa = 0.0
    area_cov_table[sigma] = Pa
    print(f"{sigma:>12.0f} {R:>12.1f} {Pa:>12.2f}")


# ===========================================================================
# 6. SIMULACIÓN MONTE CARLO — VALIDACIÓN
# ===========================================================================
np.random.seed(42)
N_MC = 100_000   # puntos de simulación

def monte_carlo_coverage(sigma_db, R_cell, n=N_MC):
    """
    Simulación Monte Carlo: distribuye n terminales uniformemente en el disco
    y calcula la fracción con potencia recibida >= P_min.
    """
    # Muestreo uniforme en disco (método de rechazo)
    r_mc  = R_cell * np.sqrt(np.random.uniform(0, 1, n))
    # Potencia media + shadowing log-normal
    p_mean = received_power_dbm(r_mc)
    shadow = np.random.normal(0, sigma_db, n)
    p_rx   = p_mean + shadow
    return np.mean(p_rx >= P_MIN_DBM)


print("\n--- Tabla 4: Validación Monte Carlo de Cobertura de Área ---")
print(f"{'sigma (dB)':>12} {'P_area analítica (%)':>22} {'P_area MC (%)':>15}")
print("-" * 52)
mc_cov_table = {}
for sigma in SIGMA_VALUES_DB:
    R = radius_table[sigma]
    if R > 0:
        Pa_mc = monte_carlo_coverage(sigma, R) * 100
    else:
        Pa_mc = 0.0
    mc_cov_table[sigma] = Pa_mc
    print(f"{sigma:>12.0f} {area_cov_table[sigma]:>22.2f} {Pa_mc:>15.2f}")


# ===========================================================================
# 7. FIGURAS
# ===========================================================================

# ---- PALETA DE COLORES ----
COLORS = ["#1f77b4", "#2ca02c", "#d62728", "#9467bd", "#ff7f0e"]

# ---------------------------------------------------------------------------
# FIGURA 1 — CDF de Potencia Recibida en el Borde de Celda
# ---------------------------------------------------------------------------
fig1, axes1 = plt.subplots(1, 2, figsize=(14, 6))
fig1.suptitle(
    "Figura 1 — CDF de Potencia Recibida en el Borde de Celda\n"
    "Polígono Logístico LTE · Cobertura perimetral objetivo: 95%",
    fontsize=13, fontweight="bold", y=1.01
)

# Subplot izquierdo: CDF para sigma fijo, varios radios
ax = axes1[0]
sigma_ref = 8   # sigma de referencia
radios_plot = [500, 700, 900, 1100]
p_vals = np.linspace(-130, -60, 1000)

for i, R in enumerate(radios_plot):
    mu = received_power_dbm(R)
    cdf = stats.norm.cdf(p_vals, loc=mu, scale=sigma_ref)
    ax.plot(p_vals, cdf * 100, color=COLORS[i], lw=2,
            label=f"R = {R} m  (μ = {mu:.1f} dBm)")

ax.axvline(P_MIN_DBM, color="black", lw=1.5, ls="--", label=f"P_min = {P_MIN_DBM} dBm")
ax.axhline(95, color="gray", lw=1.2, ls=":", label="95% objetivo")
ax.set_xlabel("Potencia recibida [dBm]")
ax.set_ylabel("Probabilidad acumulada [%]")
ax.set_title(f"CDF por radio de celda (σ = {sigma_ref} dB)")
ax.legend(fontsize=9)
ax.set_xlim(-130, -60)
ax.set_ylim(0, 100)

# Subplot derecho: CDF para radio fijo, varios sigma
ax = axes1[1]
R_ref = 900   # radio de referencia
mu_ref = received_power_dbm(R_ref)

for i, sigma in enumerate(SIGMA_VALUES_DB):
    cdf = stats.norm.cdf(p_vals, loc=mu_ref, scale=sigma)
    ax.plot(p_vals, cdf * 100, color=COLORS[i], lw=2,
            label=f"σ = {sigma} dB  (M_f = {margin_table[sigma]:.1f} dB)")

ax.axvline(P_MIN_DBM, color="black", lw=1.5, ls="--", label=f"P_min = {P_MIN_DBM} dBm")
ax.axhline(95, color="gray", lw=1.2, ls=":", label="95% objetivo")
ax.set_xlabel("Potencia recibida [dBm]")
ax.set_ylabel("Probabilidad acumulada [%]")
ax.set_title(f"CDF por desviación típica (R = {R_ref} m)")
ax.legend(fontsize=9)
ax.set_xlim(-130, -60)
ax.set_ylim(0, 100)

plt.tight_layout()
fig1.savefig(OUTPUT_DIR + "fig1_cdf_potencia.png")
plt.close(fig1)
print("\n[OK] Figura 1 guardada: fig1_cdf_potencia.png")


# ---------------------------------------------------------------------------
# FIGURA 2 — Margen de Shadowing vs Sigma y Radio Útil vs Sigma
# ---------------------------------------------------------------------------
fig2, axes2 = plt.subplots(1, 2, figsize=(14, 6))
fig2.suptitle(
    "Figura 2 — Margen de Shadowing y Radio Útil de Celda\n"
    "Polígono Logístico LTE",
    fontsize=13, fontweight="bold", y=1.01
)

sigma_cont = np.linspace(1, 15, 300)
coverages  = [0.90, 0.95, 0.99]
cov_colors = ["#2ca02c", "#1f77b4", "#d62728"]
cov_labels = ["90%", "95%", "99%"]

# Subplot izquierdo: Margen vs sigma para distintas coberturas
ax = axes2[0]
for cov, col, lbl in zip(coverages, cov_colors, cov_labels):
    margins = sigma_cont * stats.norm.ppf(cov)
    ax.plot(sigma_cont, margins, color=col, lw=2.2, label=f"Cobertura {lbl}")

# Marcar los puntos de diseño (sigma 6, 8, 10 dB a 95%)
for sigma in [6, 8, 10]:
    M = margin_table[sigma]
    ax.scatter(sigma, M, s=80, zorder=5, color="#1f77b4")
    ax.annotate(f"{M:.1f} dB", xy=(sigma, M),
                xytext=(sigma + 0.3, M + 0.5), fontsize=9)

ax.set_xlabel("Desviación típica σ [dB]")
ax.set_ylabel("Margen de desvanecimiento M_f [dB]")
ax.set_title("Margen de Shadowing vs σ")
ax.legend()
ax.set_xlim(1, 15)
ax.set_ylim(0, 35)

# Subplot derecho: Radio útil vs sigma
ax = axes2[1]
sigmas_plot = np.array(SIGMA_VALUES_DB)
radios_util = np.array([radius_table[s] for s in SIGMA_VALUES_DB])
areas_util  = np.pi * radios_util**2 / 1e6

bars = ax.bar(sigmas_plot, radios_util, width=1.2,
              color=COLORS[:len(SIGMA_VALUES_DB)], alpha=0.8, edgecolor="white")
ax2r = ax.twinx()
ax2r.plot(sigmas_plot, areas_util, "k--o", lw=1.8, ms=6, label="Área (km²)")
ax2r.set_ylabel("Área de cobertura [km²]", fontsize=11)
ax2r.tick_params(axis="y", labelsize=10)

for bar, R, A in zip(bars, radios_util, areas_util):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 10,
            f"{R:.0f} m", ha="center", va="bottom", fontsize=9, fontweight="bold")

ax.set_xlabel("Desviación típica σ [dB]")
ax.set_ylabel("Radio útil de celda R_util [m]")
ax.set_title("Radio Útil de Celda vs σ (cobertura 95%)")
ax.set_xticks(sigmas_plot)
ax2r.legend(loc="upper right")

plt.tight_layout()
fig2.savefig(OUTPUT_DIR + "fig2_margen_radio.png")
plt.close(fig2)
print("[OK] Figura 2 guardada: fig2_margen_radio.png")


# ---------------------------------------------------------------------------
# FIGURA 3 — Perfil de Potencia Media y Margen de Shadowing
# ---------------------------------------------------------------------------
fig3, ax = plt.subplots(figsize=(12, 6))
fig3.suptitle(
    "Figura 3 — Perfil de Potencia Media y Margen de Shadowing\n"
    "Polígono Logístico LTE · COST-231 Hata Suburbano",
    fontsize=13, fontweight="bold"
)

d_arr = np.linspace(50, 2000, 1000)
p_mean_arr = received_power_dbm(d_arr)

ax.plot(d_arr, p_mean_arr, "k-", lw=2.5, label="Potencia media P_rx(d)")
ax.axhline(P_MIN_DBM, color="red", lw=1.8, ls="--",
           label=f"Umbral P_min = {P_MIN_DBM} dBm")

fill_colors = ["#aec6e8", "#74b0d4", "#3a8cc1", "#1a5f8a", "#0d3a5c"]
for i, sigma in enumerate(SIGMA_VALUES_DB):
    M = margin_table[sigma]
    p_with_margin = p_mean_arr - M
    ax.plot(d_arr, p_with_margin, lw=1.5, ls="-.",
            color=COLORS[i], alpha=0.85,
            label=f"P_rx − M_f  (σ={sigma} dB, M_f={M:.1f} dB)")
    # Marcar radio útil
    R = radius_table[sigma]
    if R > 0 and R < 2000:
        ax.axvline(R, color=COLORS[i], lw=0.8, ls=":", alpha=0.6)

ax.fill_between(d_arr, P_MIN_DBM, p_mean_arr,
                where=p_mean_arr >= P_MIN_DBM,
                alpha=0.08, color="green", label="Zona de cobertura media")

ax.set_xlabel("Distancia a la BS [m]")
ax.set_ylabel("Potencia recibida [dBm]")
ax.set_xlim(50, 2000)
ax.set_ylim(-130, -60)
ax.legend(fontsize=9, loc="upper right")

plt.tight_layout()
fig3.savefig(OUTPUT_DIR + "fig3_perfil_potencia.png")
plt.close(fig3)
print("[OK] Figura 3 guardada: fig3_perfil_potencia.png")


# ---------------------------------------------------------------------------
# FIGURA 4 — Mapa de Cobertura 2D del Polígono Logístico
# ---------------------------------------------------------------------------
fig4, axes4 = plt.subplots(1, 2, figsize=(14, 6))
fig4.suptitle(
    "Figura 4 — Mapa de Cobertura 2D · Polígono Logístico LTE\n"
    "Izquierda: sin margen de shadowing | Derecha: con margen (σ = 8 dB, 95%)",
    fontsize=12, fontweight="bold", y=1.01
)

sigma_map = 8
M_map     = margin_table[sigma_map]
R_map     = radius_table[sigma_map]

# Grid 2D
grid_size = 2000   # m
res       = 200    # puntos por eje
x_grid    = np.linspace(-grid_size / 2, grid_size / 2, res)
y_grid    = np.linspace(-grid_size / 2, grid_size / 2, res)
XX, YY    = np.meshgrid(x_grid, y_grid)
D_grid    = np.sqrt(XX**2 + YY**2)
D_grid    = np.maximum(D_grid, 1)

P_grid    = received_power_dbm(D_grid)

# Shadowing aleatorio (semilla fija para reproducibilidad)
np.random.seed(7)
shadow_grid = np.random.normal(0, sigma_map, P_grid.shape)
P_grid_sh   = P_grid + shadow_grid

# Colormap personalizado
from matplotlib.colors import LinearSegmentedColormap
cmap_cov = LinearSegmentedColormap.from_list(
    "cov", ["#d62728", "#ff7f0e", "#ffdd57", "#2ca02c"], N=256
)

vmin, vmax = -120, -70

for ax_idx, (P_plot, title) in enumerate([
    (P_grid,    "Sin margen de shadowing"),
    (P_grid_sh, f"Con shadowing (σ = {sigma_map} dB)")
]):
    ax = axes4[ax_idx]
    im = ax.pcolormesh(XX / 1000, YY / 1000, P_plot,
                       cmap=cmap_cov, vmin=vmin, vmax=vmax, shading="auto")
    # Contorno de umbral
    ax.contour(XX / 1000, YY / 1000, P_plot,
               levels=[P_MIN_DBM], colors="white", linewidths=2,
               linestyles="--")
    # Círculo de radio útil
    circle = Circle((0, 0), R_map / 1000, fill=False,
                    edgecolor="cyan", lw=2, ls="-", label=f"R_util = {R_map:.0f} m")
    ax.add_patch(circle)
    # BS en el centro
    ax.plot(0, 0, "w^", ms=10, zorder=5, label="BS")
    ax.set_xlabel("x [km]")
    ax.set_ylabel("y [km]")
    ax.set_title(title, fontsize=11)
    ax.set_aspect("equal")
    ax.legend(fontsize=9, loc="upper right")
    cb = plt.colorbar(im, ax=ax, shrink=0.85)
    cb.set_label("Potencia recibida [dBm]")

plt.tight_layout()
fig4.savefig(OUTPUT_DIR + "fig4_mapa_cobertura.png")
plt.close(fig4)
print("[OK] Figura 4 guardada: fig4_mapa_cobertura.png")


# ---------------------------------------------------------------------------
# FIGURA 5 — Cobertura de Área Analítica vs Monte Carlo
# ---------------------------------------------------------------------------
fig5, axes5 = plt.subplots(1, 2, figsize=(14, 6))
fig5.suptitle(
    "Figura 5 — Cobertura de Área: Análisis Analítico vs Monte Carlo\n"
    "Polígono Logístico LTE",
    fontsize=13, fontweight="bold", y=1.01
)

# Subplot izquierdo: Cobertura de área vs radio para varios sigma
ax = axes5[0]
r_range = np.linspace(100, 1500, 60)

for i, sigma in enumerate(SIGMA_VALUES_DB):
    pa_arr = [area_coverage_probability(sigma, R) * 100 for R in r_range]
    ax.plot(r_range, pa_arr, color=COLORS[i], lw=2,
            label=f"σ = {sigma} dB")

ax.axhline(95, color="black", lw=1.5, ls="--", label="95% objetivo")
ax.axhline(90, color="gray",  lw=1.2, ls=":",  label="90% referencia")
ax.set_xlabel("Radio de celda R [m]")
ax.set_ylabel("Cobertura de área P_area [%]")
ax.set_title("Cobertura de Área vs Radio de Celda")
ax.legend(fontsize=9)
ax.set_xlim(100, 1500)
ax.set_ylim(50, 100)

# Subplot derecho: Comparación analítica vs MC por sigma
ax = axes5[1]
x_pos = np.arange(len(SIGMA_VALUES_DB))
width = 0.35

pa_anal = [area_cov_table[s] for s in SIGMA_VALUES_DB]
pa_mc   = [mc_cov_table[s]   for s in SIGMA_VALUES_DB]

bars1 = ax.bar(x_pos - width / 2, pa_anal, width, label="Analítico",
               color="#1f77b4", alpha=0.85, edgecolor="white")
bars2 = ax.bar(x_pos + width / 2, pa_mc,   width, label="Monte Carlo",
               color="#2ca02c", alpha=0.85, edgecolor="white")

ax.axhline(95, color="red", lw=1.5, ls="--", label="95% objetivo")
ax.set_xlabel("Desviación típica σ [dB]")
ax.set_ylabel("Cobertura de área [%]")
ax.set_title("Analítico vs Monte Carlo (R = R_util)")
ax.set_xticks(x_pos)
ax.set_xticklabels([f"σ={s}" for s in SIGMA_VALUES_DB])
ax.legend()
ax.set_ylim(80, 100)

for bar in bars1:
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.1,
            f"{bar.get_height():.1f}", ha="center", va="bottom", fontsize=8)
for bar in bars2:
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.1,
            f"{bar.get_height():.1f}", ha="center", va="bottom", fontsize=8)

plt.tight_layout()
fig5.savefig(OUTPUT_DIR + "fig5_cobertura_area.png")
plt.close(fig5)
print("[OK] Figura 5 guardada: fig5_cobertura_area.png")


# ---------------------------------------------------------------------------
# FIGURA 6 — Extensión Opcional: Coste de Celda Adicional vs Margen
# ---------------------------------------------------------------------------
fig6, axes6 = plt.subplots(1, 2, figsize=(14, 6))
fig6.suptitle(
    "Figura 6 — Extensión: Coste de Despliegue vs Margen de Shadowing\n"
    "Polígono Logístico LTE · Análisis Económico Simplificado",
    fontsize=13, fontweight="bold", y=1.01
)

# Parámetros económicos (valores orientativos)
AREA_LOGISTICA_KM2  = 2.0    # Área total del polígono logístico [km²]
COSTE_CELDA_EUR     = 80_000  # Coste despliegue de una celda LTE [€]
COSTE_OPEX_EUR_AÑO  = 15_000  # OPEX anual por celda [€]
AÑOS_VIDA           = 10      # Horizonte de análisis [años]

# Número de celdas necesarias para cubrir el polígono
def n_celdas(R_m):
    """Número de celdas hexagonales para cubrir el área."""
    area_celda_hex = 2.6 * R_m**2 / 1e6   # km² (factor hexagonal ~2.6)
    return np.ceil(AREA_LOGISTICA_KM2 / area_celda_hex)

# Coste total (CAPEX + OPEX)
def coste_total(n):
    return n * (COSTE_CELDA_EUR + COSTE_OPEX_EUR_AÑO * AÑOS_VIDA)

# Subplot izquierdo: N° celdas y coste vs sigma
ax = axes6[0]
sigmas_arr = np.array(SIGMA_VALUES_DB)
radios_arr = np.array([radius_table[s] for s in SIGMA_VALUES_DB])
n_cells    = np.array([n_celdas(R) for R in radios_arr])
costes     = np.array([coste_total(n) / 1e3 for n in n_cells])   # k€

color_bars = COLORS[:len(SIGMA_VALUES_DB)]
bars = ax.bar(sigmas_arr, costes, width=1.2, color=color_bars,
              alpha=0.85, edgecolor="white")
ax2 = ax.twinx()
ax2.plot(sigmas_arr, n_cells, "k--o", lw=2, ms=7, label="N° celdas")
ax2.set_ylabel("Número de celdas necesarias", fontsize=11)
ax2.tick_params(axis="y", labelsize=10)

for bar, c, n in zip(bars, costes, n_cells):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 5,
            f"{c:.0f} k€\n({n:.0f} celdas)", ha="center", va="bottom",
            fontsize=8.5, fontweight="bold")

ax.set_xlabel("Desviación típica σ [dB]")
ax.set_ylabel("Coste total CAPEX+OPEX [k€]", fontsize=11)
ax.set_title(f"Coste de Despliegue vs σ\n(Área logística = {AREA_LOGISTICA_KM2} km²)")
ax.set_xticks(sigmas_arr)
ax2.legend(loc="upper left")

# Subplot derecho: Curva coste vs cobertura objetivo
ax = axes6[1]
cov_range   = np.linspace(0.80, 0.999, 100)
sigma_cases = [6, 8, 10]

for i, sigma in enumerate(sigma_cases):
    radios_cov = np.array([cell_radius_with_margin(sigma, cov) for cov in cov_range])
    n_cov      = np.array([n_celdas(R) for R in radios_cov])
    cost_cov   = np.array([coste_total(n) / 1e3 for n in n_cov])
    ax.plot(cov_range * 100, cost_cov, color=COLORS[i], lw=2.2,
            label=f"σ = {sigma} dB")

ax.axvline(95, color="black", lw=1.5, ls="--", label="95% objetivo")
ax.set_xlabel("Cobertura perimetral objetivo [%]")
ax.set_ylabel("Coste total CAPEX+OPEX [k€]")
ax.set_title("Coste de Despliegue vs Cobertura Objetivo")
ax.legend()
ax.set_xlim(80, 99.9)

plt.tight_layout()
fig6.savefig(OUTPUT_DIR + "fig6_coste_despliegue.png")
plt.close(fig6)
print("[OK] Figura 6 guardada: fig6_coste_despliegue.png")


# ---------------------------------------------------------------------------
# FIGURA 7 — Tabla Resumen Visual
# ---------------------------------------------------------------------------
fig7, ax = plt.subplots(figsize=(13, 5))
fig7.suptitle(
    "Tabla Resumen — Diseño con Margen de Shadowing · Polígono Logístico LTE",
    fontsize=13, fontweight="bold"
)
ax.axis("off")

col_labels = [
    "σ (dB)", "z₀.₉₅", "Margen M_f (dB)",
    "R_util (m)", "Área (km²)", "P_area Anal. (%)", "P_area MC (%)",
    "N° celdas\n(2 km²)", "Coste total\n(k€)"
]

table_data = []
for sigma in SIGMA_VALUES_DB:
    z    = stats.norm.ppf(0.95)
    M    = margin_table[sigma]
    R    = radius_table[sigma]
    A    = area_table[sigma]
    Pa   = area_cov_table[sigma]
    Pa_m = mc_cov_table[sigma]
    n    = n_celdas(R)
    cost = coste_total(n) / 1e3
    table_data.append([
        f"{sigma}",
        f"{z:.4f}",
        f"{M:.2f}",
        f"{R:.0f}",
        f"{A:.4f}",
        f"{Pa:.2f}",
        f"{Pa_m:.2f}",
        f"{n:.0f}",
        f"{cost:.0f}"
    ])

tbl = ax.table(
    cellText=table_data,
    colLabels=col_labels,
    loc="center",
    cellLoc="center"
)
tbl.auto_set_font_size(False)
tbl.set_fontsize(10)
tbl.scale(1.0, 2.0)

# Colorear encabezado
for j in range(len(col_labels)):
    tbl[(0, j)].set_facecolor("#1f4e79")
    tbl[(0, j)].set_text_props(color="white", fontweight="bold")

# Colorear filas alternas
for i in range(1, len(SIGMA_VALUES_DB) + 1):
    fc = "#dce6f1" if i % 2 == 0 else "#ffffff"
    for j in range(len(col_labels)):
        tbl[(i, j)].set_facecolor(fc)

plt.tight_layout()
fig7.savefig(OUTPUT_DIR + "fig7_tabla_resumen.png")
plt.close(fig7)
print("[OK] Figura 7 guardada: fig7_tabla_resumen.png")


# ===========================================================================
# 8. RESUMEN FINAL EN CONSOLA
# ===========================================================================
print("\n" + "=" * 65)
print("  RESUMEN FINAL DEL DISEÑO")
print("=" * 65)
print(f"  Cobertura objetivo    : {TARGET_COVERAGE*100:.0f}%")
print(f"  Percentil gaussiano   : z = {stats.norm.ppf(TARGET_COVERAGE):.4f}")
print(f"  Umbral P_min          : {P_MIN_DBM} dBm")
print()
print(f"  {'sigma':>6} | {'M_f':>8} | {'R_util':>8} | {'P_area':>8} | {'N_celdas':>9}")
print(f"  {'(dB)':>6} | {'(dB)':>8} | {'(m)':>8} | {'(%)':>8} | {'(2 km²)':>9}")
print("  " + "-" * 52)
for sigma in SIGMA_VALUES_DB:
    M  = margin_table[sigma]
    R  = radius_table[sigma]
    Pa = area_cov_table[sigma]
    n  = n_celdas(R)
    print(f"  {sigma:>6} | {M:>8.2f} | {R:>8.1f} | {Pa:>8.2f} | {n:>9.0f}")
print("=" * 65)
print("\n[COMPLETADO] Todas las figuras y tablas han sido generadas.")
